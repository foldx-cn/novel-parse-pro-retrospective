# 集成说明

## Python 本地服务

在 `novel_server.py` 启动时：

```python
import download_center
download_center.configure(DATA_DIR)
```

然后注册这些路由（GET/POST）：

```text
GET  /api/downloads
GET  /api/platforms
GET  /api/accounts
POST /api/link/parse
POST /api/media/probe
POST /api/downloads/add
POST /api/downloads/pause
POST /api/downloads/resume
POST /api/downloads/remove
POST /api/downloads/open
POST /api/accounts/save
POST /api/accounts/delete
```

`download_center.configure(data_dir)` 会在 `data_dir/downloads` 下保存文件，任务元数据为 `tasks.json`，账号为 `accounts.json`，分片临时文件为 `.part`。

## Android WebView

登录使用原生 WebView 遮罩，不把账号密码交给网页：

1. JS 调用 `Bridge.openLogin(platform, url)`；
2. `MainActivity` 打开登录页，顶部提供取消/完成；
3. 用户登录完成后读取 `CookieManager.getCookie(currentUrl)`；
4. 通过 `evaluateJavascript("window.onPlatformCookie(...)")` 回传；
5. 前端调用 `/api/accounts/save`，服务只存 Cookie，不返回 Cookie 本体。

## 已验证

- 公开直链 23.6 MB APK：Range 分片下载完成，状态 `done`。
- 分享链接：识别平台/类型/提取码，返回 `downloadable:false`，不误下 HTML。
- 公开页面：返回 `og:title`、`og:image`、`og:video` 与页面媒体项。
- 账号接口：保存后列表只返回 `hasCookie`。

## 未验证/未实现

- 夸克、UC、百度等平台的私有文件列表和登录后文件直链。
- 抖音、小红书、B 站等平台的私有播放/图集接口。
- 需要平台风控、验证码或付费权限的场景。

这些边界不是“以后再说”，而是当前版本明确不做的部分；请按平台条款使用。
