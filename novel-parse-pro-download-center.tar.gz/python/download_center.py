"""下载中心 · 本机下载与公开链接解析。

功能参考自 YunX（https://github.com/CYQawa/YunX，AGPL-3.0）的下载管理、
Range 分片、断点续传、网盘/视频/图集链接识别和多平台登录入口；
本文件是小说解析项目内的独立实现，不复制 YunX 源码。

设计边界：
- 只处理 http(s) 公开链接；不绕过登录、付费墙、验证码或 DRM。
- 网盘/视频平台的私有接口需要平台账号，界面提供登录入口和 Cookie 保存，
  具体文件列表与播放地址仍以平台实际返回为准。
- 下载文件只写入 App 自己的数据目录，文件名经过清洗，不能越出目录。
"""
from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import re
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable
from urllib.parse import quote, unquote, urlparse
from urllib.request import Request, urlopen

VERSION = "1.6.0"
CHUNK = 4 * 1024 * 1024
WORKERS = 4

UA = ("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")

PLATFORMS = [
    {"id": "quark", "name": "夸克网盘", "kind": "netdisk", "hosts": ["pan.quark.cn"],
     "login": "https://pan.quark.cn/", "color": "#4f7cff"},
    {"id": "uc", "name": "UC 网盘", "kind": "netdisk", "hosts": ["drive.uc.cn", "fast.uc.cn"],
     "login": "https://drive.uc.cn/", "color": "#f59e0b"},
    {"id": "xunlei", "name": "迅雷网盘", "kind": "netdisk", "hosts": ["pan.xunlei.com"],
     "login": "https://pan.xunlei.com/", "color": "#35a7ff"},
    {"id": "baidu", "name": "百度网盘", "kind": "netdisk", "hosts": ["pan.baidu.com", "yun.baidu.com"],
     "login": "https://pan.baidu.com/", "color": "#2d8cf0"},
    {"id": "139", "name": "移动云盘", "kind": "netdisk", "hosts": ["caiyun.139.com", "yun.139.com"],
     "login": "https://caiyun.139.com/", "color": "#20b26b"},
    {"id": "123", "name": "123 云盘", "kind": "netdisk", "hosts": ["123pan.com", "123684.com"],
     "login": "https://www.123pan.com/", "color": "#6c5ce7"},
    {"id": "115", "name": "115 网盘", "kind": "netdisk", "hosts": ["115.com", "115cdn.com"],
     "login": "https://115.com/", "color": "#f04e4e"},
    {"id": "guangya", "name": "光鸭云盘", "kind": "netdisk", "hosts": ["guangyapan.com", "guangya.com"],
     "login": "https://www.guangyapan.com/", "color": "#ffb020"},
    {"id": "lanzou", "name": "蓝奏云", "kind": "netdisk", "hosts": ["lanzou.com", "lanzoui.com", "lanzoux.com", "lanzouy.com"],
     "login": "https://www.lanzou.com/", "color": "#00a6a6"},
    {"id": "lanzoupro", "name": "蓝奏云优享版", "kind": "netdisk", "hosts": ["lanzouo.com", "lanzouj.com"],
     "login": "https://www.lanzouo.com/", "color": "#00a6a6"},
    {"id": "douyin", "name": "抖音", "kind": "video", "hosts": ["douyin.com", "iesdouyin.com"],
     "login": "https://www.douyin.com/", "color": "#161823"},
    {"id": "xiaohongshu", "name": "小红书", "kind": "gallery", "hosts": ["xiaohongshu.com", "xhslink.com"],
     "login": "https://www.xiaohongshu.com/", "color": "#ff2442"},
    {"id": "kuaishou", "name": "快手", "kind": "video", "hosts": ["kuaishou.com", "gifshow.com"],
     "login": "https://www.kuaishou.com/", "color": "#ff5000"},
    {"id": "weibo", "name": "微博", "kind": "video", "hosts": ["weibo.com", "weibo.cn"],
     "login": "https://weibo.com/", "color": "#e6162d"},
    {"id": "acfun", "name": "AcFun", "kind": "video", "hosts": ["acfun.cn"],
     "login": "https://www.acfun.cn/", "color": "#fd4f00"},
    {"id": "bilibili", "name": "哔哩哔哩", "kind": "video", "hosts": ["bilibili.com", "b23.tv"],
     "login": "https://www.bilibili.com/", "color": "#fb7299"},
    {"id": "pixiv", "name": "Pixiv", "kind": "gallery", "hosts": ["pixiv.net"],
     "login": "https://www.pixiv.net/", "color": "#0096fa"},
]

EXT_KIND = {
    ".mp4": "video", ".m4v": "video", ".mov": "video", ".webm": "video", ".mkv": "video",
    ".m3u8": "video", ".ts": "video",
    ".jpg": "image", ".jpeg": "image", ".png": "image", ".gif": "image", ".webp": "image",
    ".bmp": "image", ".avif": "image",
    ".mp3": "audio", ".m4a": "audio", ".aac": "audio", ".flac": "audio", ".wav": "audio",
    ".zip": "file", ".rar": "file", ".7z": "file", ".pdf": "file", ".epub": "file",
    ".txt": "file", ".bin": "file", ".apk": "file",
}

MIME_EXT = {
    "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov",
    "audio/mpeg": ".mp3", "audio/mp4": ".m4a", "audio/aac": ".aac",
    "image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif",
    "image/webp": ".webp", "application/pdf": ".pdf",
    "application/epub+zip": ".epub", "application/zip": ".zip",
    "text/plain": ".txt",
}


def _safe(name: str, fallback: str = "download") -> str:
    name = unquote(str(name or "")).replace("\\", "/").split("/")[-1]
    name = re.sub(r"[\x00-\x1f<>:\"/\\|?*]+", "_", name).strip(" ._")
    if not name:
        name = fallback
    stem, ext = os.path.splitext(name)
    stem = stem[:100] or fallback
    return stem + ext[:12]


def _fmt_bytes(n: int) -> str:
    n = max(0, int(n or 0))
    if n >= 1024 * 1024 * 1024:
        return "%.1f GB" % (n / 1024 ** 3)
    if n >= 1024 * 1024:
        return "%.1f MB" % (n / 1024 ** 2)
    if n >= 1024:
        return "%.1f KB" % (n / 1024)
    return "%d B" % n


def platform_for(url: str) -> dict | None:
    host = (urlparse(url).hostname or "").lower()
    for p in PLATFORMS:
        if any(host == h or host.endswith("." + h) for h in p["hosts"]):
            return p
    return None


def detect_kind(url: str, content_type: str = "") -> str:
    ext = os.path.splitext(urlparse(url).path)[1].lower()
    if ext in EXT_KIND:
        return EXT_KIND[ext]
    ct = (content_type or "").split(";")[0].strip().lower()
    if ct.startswith("video/"):
        return "video"
    if ct.startswith("image/"):
        return "image"
    if ct.startswith("audio/"):
        return "audio"
    if ct in ("application/pdf", "application/epub+zip", "application/zip"):
        return "file"
    return "page"


def share_code(text: str) -> str:
    m = re.search(r"(?:提取码|访问码|密码|口令|pwd|code)[\s:：=]*([a-zA-Z0-9]{4,8})", text or "", re.I)
    if m:
        return m.group(1)
    m = re.search(r"[?&](?:pwd|password|code)=([a-zA-Z0-9]{4,8})", text or "", re.I)
    return m.group(1) if m else ""


def extract_url(text: str) -> str:
    m = re.search(r"https?://[^\s<>\"']+", text or "", re.I)
    if not m:
        return ""
    return m.group(0).rstrip("，。,.、）)】]}>")


def parse_text(text: str) -> dict:
    """只做识别，不假装已经拿到平台私有文件列表。"""
    url = extract_url(text)
    if not url:
        return {"ok": False, "error": "没有找到 http(s) 链接"}
    p = platform_for(url)
    code = share_code(text)
    kind = p["kind"] if p else detect_kind(url)
    out = {
        "ok": True,
        "url": url,
        "shareCode": code,
        "kind": kind,
        "platform": p or {"id": "direct", "name": "直链 / 公开页面", "kind": kind,
                          "login": "", "color": "#5b8def"},
        "known": bool(p),
        "downloadable": (not bool(p)) and kind in ("video", "image", "audio", "file"),
    }
    if p:
        out["hint"] = ("已识别为%s。提取码：%s。可先登录平台，再粘贴文件直链加入下载。"
                       % (p["name"], code or "无")) if p["kind"] == "netdisk" else (
                       "已识别为%s。公开页面可点「解析媒体」抓取标题、封面和公开媒体地址；"
                       "需要登录的内容请先完成平台登录。" % p["name"])
    else:
        out["hint"] = "这是普通链接；直链可直接加入下载，网页可尝试解析公开媒体。"
    return out


class _MetaParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title = ""
        self.metas: dict[str, str] = {}
        self.links: list[str] = []
        self.images: list[str] = []
        self.videos: list[str] = []
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "title":
            self._in_title = True
        elif tag == "meta":
            key = (a.get("property") or a.get("name") or "").lower()
            if key and a.get("content"):
                self.metas.setdefault(key, a["content"].strip())
        elif tag in ("img", "source", "video"):
            for key in ("src", "data-src", "data-original", "poster"):
                if a.get(key):
                    val = a[key].strip()
                    if val.startswith("//"):
                        val = "https:" + val
                    if tag == "img" or key == "poster":
                        if val not in self.images:
                            self.images.append(val)
                    elif val not in self.videos:
                        self.videos.append(val)
        elif tag == "a" and a.get("href"):
            href = a["href"].strip()
            if href.startswith("//"):
                href = "https:" + href
            if href not in self.links:
                self.links.append(href)

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title:
            self.title += data


def _fetch(url: str, cookie: str = "", timeout: int = 18, limit: int = 3_000_000):
    headers = {"User-Agent": UA, "Accept": "*/*", "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6"}
    if cookie:
        headers["Cookie"] = cookie
    req = Request(url, headers=headers)
    r = urlopen(req, timeout=timeout)
    ct = r.headers.get("Content-Type", "")
    cl = r.headers.get("Content-Length")
    return r, r.read(limit), ct, int(cl) if (cl or "").isdigit() else 0


def _media_name(url: str, idx: int, kind: str) -> str:
    name = _safe(os.path.basename(urlparse(url).path), fallback="%s_%d" % (kind, idx))
    if not os.path.splitext(name)[1]:
        ext = {"image": ".jpg", "video": ".mp4", "audio": ".mp3", "file": ".bin"}.get(kind, ".bin")
        name += ext
    return name


def probe(url: str, cookie: str = "") -> dict:
    """探测公开页面/直链：返回标题、封面、可下载的公开媒体。"""
    if not re.match(r"^https?://", url or "", re.I):
        return {"ok": False, "error": "只支持 http(s) 链接"}
    p = platform_for(url)
    if p and p["kind"] == "netdisk":
        return {
            "ok": True, "url": url, "platform": p, "title": p["name"] + "分享页",
            "kind": "netdisk", "items": [],
            "hint": "网盘分享的文件列表和下载地址由平台账号决定；本页提供登录入口，"
                    "登录后可把平台给出的文件直链粘贴到下载框。",
        }
    try:
        r, body, ct, cl = _fetch(url, cookie)
    except Exception as e:
        return {"ok": False, "error": "页面读取失败：%s" % e, "url": url,
                "platform": p}
    kind = detect_kind(url, ct)
    base = "%s://%s" % (urlparse(url).scheme, urlparse(url).netloc)
    if kind != "page":
        name = _media_name(url, 1, kind)
        return {"ok": True, "url": url, "platform": p, "kind": kind,
                "title": name, "size": cl, "sizeText": _fmt_bytes(cl),
                "items": [{"type": kind, "url": url, "name": name, "size": cl,
                           "mime": ct.split(";")[0]}]}
    text = body.decode("utf-8", errors="replace")
    mp = _MetaParser()
    try:
        mp.feed(text)
    except Exception:
        pass
    title = (mp.metas.get("og:title") or mp.metas.get("twitter:title") or mp.title or
             (p["name"] + "链接" if p else "网页媒体")).strip()[:120]
    cover = mp.metas.get("og:image") or mp.metas.get("twitter:image") or ""
    if cover.startswith("//"):
        cover = "https:" + cover
    items = []

    def add(u: str, typ: str):
        if not u:
            return
        if u.startswith("//"):
            u = "https:" + u
        if u.startswith("/"):
            u = base + u
        if not re.match(r"^https?://", u, re.I):
            return
        if u in [x["url"] for x in items]:
            return
        k = detect_kind(u)
        if k == "page":
            return
        if typ and k != typ and typ not in ("file",):
            return
        items.append({"type": typ or k, "url": u, "name": _media_name(u, len(items) + 1, typ or k),
                      "mime": "", "size": 0})

    for v in [mp.metas.get("og:video"), mp.metas.get("og:video:url"),
              mp.metas.get("twitter:player:stream")] + mp.videos:
        add(v, "video")
    for v in [cover] + [mp.metas.get("og:image"), mp.metas.get("twitter:image")] + mp.images:
        add(v, "image")
    for href in mp.links:
        ext = os.path.splitext(urlparse(href).path)[1].lower()
        if ext in EXT_KIND and EXT_KIND[ext] in ("video", "audio", "file") and len(items) < 40:
            add(href, EXT_KIND[ext])
    # 去掉已知的 1x1 跟踪图和空图
    items = [x for x in items if not re.search(r"(pixel|spacer|blank|transparent|1x1)", x["url"], re.I)]
    return {"ok": True, "url": url, "platform": p, "kind": p["kind"] if p else "page",
            "title": title, "cover": cover, "items": items[:40],
            "hint": "公开页面已解析；平台私有视频/图集需要登录后以平台给出的地址为准。"}


class DownloadCenter:
    def __init__(self, data_dir: Path | str):
        self.dir = Path(data_dir) / "downloads"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.meta = self.dir / "tasks.json"
        self.accounts_file = Path(data_dir) / "accounts.json"
        self.lock = threading.RLock()
        self.tasks: dict[str, dict] = {}
        self.threads: dict[str, threading.Thread] = {}
        self.pauses: dict[str, threading.Event] = {}
        self._load()

    # ---------- 持久化 ----------
    def _load(self):
        try:
            data = json.loads(self.meta.read_text(encoding="utf-8"))
            if isinstance(data, list):
                for t in data:
                    if not isinstance(t, dict) or not t.get("id"):
                        continue
                    t.setdefault("status", "paused")
                    if t["status"] in ("running", "queued"):
                        t["status"] = "paused"
                    self.tasks[t["id"]] = t
        except Exception:
            pass

    def _save(self):
        with self.lock:
            tmp = self.meta.with_suffix(".tmp")
            safe = []
            for t in self.tasks.values():
                d = {k: v for k, v in t.items() if k not in ("_pause", "_thread")}
                safe.append(d)
            tmp.write_text(json.dumps(safe, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, self.meta)

    # ---------- 账号 ----------
    def accounts(self) -> list[dict]:
        try:
            data = json.loads(self.accounts_file.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def save_account(self, pid: str, cookie: str, note: str = "") -> dict:
        pid = re.sub(r"[^a-zA-Z0-9_-]", "", pid)[:32]
        if not pid:
            raise ValueError("平台标识无效")
        cookie = str(cookie or "").strip()
        if len(cookie) > 8000:
            raise ValueError("Cookie 太长")
        out = [x for x in self.accounts() if x.get("id") != pid]
        p = next((x for x in PLATFORMS if x["id"] == pid), None)
        if not p:
            raise ValueError("未知平台")
        out.append({"id": pid, "name": p["name"], "cookie": cookie, "note": str(note or "")[:80],
                    "updated": int(time.time())})
        self.accounts_file.parent.mkdir(parents=True, exist_ok=True)
        self.accounts_file.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
        return next(x for x in out if x["id"] == pid)

    def delete_account(self, pid: str):
        out = [x for x in self.accounts() if x.get("id") != pid]
        self.accounts_file.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")

    def account_cookie(self, pid: str) -> str:
        return next((x.get("cookie", "") for x in self.accounts() if x.get("id") == pid), "")

    def public_accounts(self) -> list[dict]:
        return [{k: v for k, v in x.items() if k != "cookie"} | {"hasCookie": bool(x.get("cookie"))}
                for x in self.accounts()]

    # ---------- 任务 ----------
    def list_tasks(self) -> list[dict]:
        with self.lock:
            out = []
            for t in self.tasks.values():
                d = dict(t)
                d.pop("_pause", None)
                d["sizeText"] = _fmt_bytes(t.get("size") or 0)
                d["progressText"] = "%s / %s" % (_fmt_bytes(t.get("downloaded") or 0),
                                                 _fmt_bytes(t.get("size") or 0))
                out.append(d)
            return sorted(out, key=lambda x: x.get("created") or 0, reverse=True)

    def find(self, tid: str) -> dict | None:
        return self.tasks.get(tid)

    def add(self, url: str, name: str = "", platform: str = "", cookie: str = "") -> dict:
        if not re.match(r"^https?://", url or "", re.I):
            raise ValueError("链接要以 http:// 或 https:// 开头")
        url = url.strip()
        p = platform_for(url)
        pid = platform or (p["id"] if p else "direct")
        tid = hashlib.md5((url + str(time.time())).encode()).hexdigest()[:12]
        task = {
            "id": tid, "url": url, "name": _safe(name or os.path.basename(urlparse(url).path) or "download"),
            "platform": pid, "status": "new", "size": 0, "downloaded": 0,
            "created": int(time.time()), "updated": int(time.time()), "path": "",
            "error": "", "speed": 0, "parts": [], "partFile": str(self.dir / (tid + ".part")),
        }
        with self.lock:
            self.tasks[tid] = task
            self._save()
        self.start(tid, cookie)
        return task

    def start(self, tid: str, cookie: str = ""):
        with self.lock:
            t = self.tasks.get(tid)
            if not t:
                raise ValueError("任务不存在")
            if t.get("status") == "running":
                return
            t["status"] = "queued"
            t["error"] = ""
            self.pauses[tid] = threading.Event()
            th = threading.Thread(target=self._run, args=(tid, cookie), daemon=True,
                                  name="dl-" + tid)
            self.threads[tid] = th
            th.start()

    def pause(self, tid: str):
        with self.lock:
            t = self.tasks.get(tid)
            if not t:
                raise ValueError("任务不存在")
            ev = self.pauses.get(tid)
            if ev:
                ev.set()
            if t["status"] in ("running", "queued"):
                t["status"] = "paused"
                t["updated"] = int(time.time())
                self._save()

    def resume(self, tid: str, cookie: str = ""):
        with self.lock:
            t = self.tasks.get(tid)
            if not t:
                raise ValueError("任务不存在")
            if t.get("status") == "running":
                return
            self.start(tid, cookie)

    def remove(self, tid: str, delete_file: bool = False):
        with self.lock:
            t = self.tasks.pop(tid, None)
            ev = self.pauses.pop(tid, None)
            if ev:
                ev.set()
            self._save()
        if not t:
            return
        for f in (t.get("partFile"), t.get("path") if delete_file else ""):
            if f:
                try:
                    Path(f).unlink()
                except Exception:
                    pass

    def _update(self, tid: str, **kw):
        with self.lock:
            t = self.tasks.get(tid)
            if not t:
                return
            t.update(kw)
            t["updated"] = int(time.time())
            self._save()

    def _head(self, url: str, cookie: str = "") -> tuple[int, bool, str, str]:
        headers = {"User-Agent": UA, "Accept": "*/*"}
        if cookie:
            headers["Cookie"] = cookie
        req = Request(url, headers=headers, method="HEAD")
        try:
            r = urlopen(req, timeout=15)
            total = int(r.headers.get("Content-Length") or 0)
            ranges = "bytes" in (r.headers.get("Accept-Ranges") or "").lower()
            ct = r.headers.get("Content-Type") or ""
            cd = r.headers.get("Content-Disposition") or ""
            return total, ranges, ct, cd
        except Exception:
            return 0, False, "", ""

    def _run(self, tid: str, cookie: str = ""):
        t = self.tasks.get(tid)
        if not t:
            return
        self._update(tid, status="running")
        try:
            total, ranges, ct, cd = self._head(t["url"], cookie)
            fname = ""
            m = re.search(r"filename\*?=(?:UTF-8''|)?([^\s;]+)", cd, re.I)
            if m:
                fname = _safe(unquote(m.group(1).strip('"')), t["name"])
            if (ct or "").lower().startswith("text/html"):
                raise RuntimeError("这是网页而不是文件直链；请先解析公开媒体，或使用平台给出的文件地址")
            if not fname:
                fname = _safe(t["name"], "download")
                ext = MIME_EXT.get((ct or "").split(";")[0].lower())
                if ext and not os.path.splitext(fname)[1]:
                    fname += ext
            target = self.dir / (tid + "_" + fname)
            part = Path(t["partFile"])
            with self.lock:
                t["name"] = fname
                t["size"] = total
                t["target"] = str(target)
                if not t.get("parts"):
                    t["parts"] = []
                self._save()
            if ranges and total > 0:
                self._run_ranges(tid, total, cookie)
            else:
                self._run_stream(tid, cookie)
            if self.pauses.get(tid, threading.Event()).is_set():
                self._update(tid, status="paused")
                return
            if part.exists() and part.stat().st_size > 0:
                finished = part.stat().st_size
                os.replace(part, target)
                self._update(tid, status="done", downloaded=finished, size=finished,
                             path=str(target), speed=0)
            else:
                self._update(tid, status="error", error="下载结果为空")
        except Exception as e:
            self._update(tid, status="error", error=str(e)[:200])
        finally:
            with self.lock:
                self.threads.pop(tid, None)

    def _run_stream(self, tid: str, cookie: str):
        t = self.tasks.get(tid)
        if not t:
            return
        part = Path(t["partFile"])
        part.parent.mkdir(parents=True, exist_ok=True)
        headers = {"User-Agent": UA, "Accept": "*/*"}
        if cookie:
            headers["Cookie"] = cookie
        req = Request(t["url"], headers=headers)
        got = 0
        started = time.time()
        with urlopen(req, timeout=30) as r, open(part, "wb") as f:
            while True:
                if self.pauses.get(tid, threading.Event()).is_set():
                    break
                chunk = r.read(64 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                speed = got / max(0.2, time.time() - started)
                if int(time.time() * 2) % 2 == 0:
                    self._update(tid, downloaded=got, speed=int(speed))
        self._update(tid, downloaded=got)
        if not self.pauses.get(tid, threading.Event()).is_set() and got == 0:
            raise RuntimeError("服务器没有返回内容")

    def _run_ranges(self, tid: str, total: int, cookie: str):
        t = self.tasks.get(tid)
        if not t:
            return
        part = Path(t["partFile"])
        part.parent.mkdir(parents=True, exist_ok=True)
        if not part.exists():
            with open(part, "wb") as f:
                f.truncate(total)
        done = set(int(x) for x in (t.get("parts") or []) if str(x).isdigit())
        offsets = list(range(0, total, CHUNK))
        pending = [i for i, off in enumerate(offsets) if i not in done]
        if not pending:
            self._update(tid, downloaded=sum(min(CHUNK, total - off) for off in offsets if off < total))
            return
        file_lock = threading.Lock()
        started = time.time()
        completed_now = 0

        def one(idx: int):
            nonlocal completed_now
            if self.pauses.get(tid, threading.Event()).is_set():
                return
            off = offsets[idx]
            end = min(total - 1, off + CHUNK - 1)
            headers = {"User-Agent": UA, "Range": "bytes=%d-%d" % (off, end), "Accept": "*/*"}
            if cookie:
                headers["Cookie"] = cookie
            req = Request(t["url"], headers=headers)
            with urlopen(req, timeout=30) as r:
                data = r.read(end - off + 1)
            if len(data) != end - off + 1:
                raise RuntimeError("分片长度不对：%d/%d" % (len(data), end - off + 1))
            with file_lock, open(part, "r+b") as f:
                f.seek(off)
                f.write(data)
            with self.lock:
                if idx not in done:
                    done.add(idx)
                    t["parts"] = sorted(done)
                    completed_now += len(data)
                    t["downloaded"] = min(total, sum(min(CHUNK, total - offsets[i]) for i in done))
                    t["speed"] = int(t["downloaded"] / max(0.2, time.time() - started))
                    self._save()

        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            list(pool.map(one, pending))
        if not self.pauses.get(tid, threading.Event()).is_set():
            self._update(tid, downloaded=total, size=total)

    def open_path(self, tid: str) -> dict:
        t = self.tasks.get(tid)
        if not t:
            raise ValueError("任务不存在")
        path = Path(t.get("path") or "")
        if not path.exists():
            raise ValueError("文件还没下载完")
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        return {"path": str(path), "name": path.name, "mime": mime}


# 单例：由 novel_server.start() 调用 configure
_CENTER: DownloadCenter | None = None


def configure(data_dir: Path | str) -> DownloadCenter:
    global _CENTER
    if _CENTER is None:
        _CENTER = DownloadCenter(data_dir)
    return _CENTER


def center() -> DownloadCenter:
    if _CENTER is None:
        raise RuntimeError("下载中心尚未初始化")
    return _CENTER
