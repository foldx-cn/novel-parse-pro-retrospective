package com.novelparse.pro;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.content.res.Configuration;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.content.res.AssetManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 小说解析 · Android 客户端
 *
 * 单 Activity：启动内嵌 Python 服务（只监听 127.0.0.1），WebView 显示本地页面。
 * 解析（TXT / EPUB / HTML）、切章、导出 TXT / EPUB 全部在本机完成；
 * 只有 PDF 走云端（novel.foldx.cn）排版，因为中文字体与分页排版放在服务端更稳。
 */
public class MainActivity extends Activity {

    private static final int PORT = 8696;
    private static final int REQ_FILE = 3101;
    private static final int REQ_SAVE = 3102;
    private static final String PREFS = "novelparse_prefs";

    private WebView webView;
    private FrameLayout root;
    private LinearLayout splash;
    private TextView splashText;
    private volatile int serverPort = PORT;
    private volatile boolean serverReady = false;

    private File pendingCopyTarget;   // SAF 保存的目标 Uri 由 saveUri 记录
    private Uri saveUri;
    private String saveName;
    private File saveSource;
    private String pickTargetName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new FrameLayout(this);
        root.setBackgroundColor(unlockedBg());

        webView = new WebView(this);
        webView.setBackgroundColor(unlockedBg());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setStandardFontFamily("sans-serif");
        s.setSansSerifFontFamily("sans-serif");
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(false);
            } else {
                s.setForceDark(WebSettings.FORCE_DARK_OFF);
            }
        } catch (Throwable ignored) {
        }
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && ("127.0.0.1".equals(host) || "localhost".equals(host))) return false;
                openExternal(uri);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideSplash();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                // 网页里的 <input type=file> 也能用
                pickCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "选择小说文件"), REQ_FILE);
                } catch (Exception e) {
                    pickCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        root.addView(webView, matchParent());

        // 启动遮罩
        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(unlockedBg());
        TextView title = new TextView(this);
        title.setText("小说解析");
        title.setTextSize(23);
        title.setTextColor(0xFF11151F);
        title.setGravity(Gravity.CENTER);
        ProgressBar bar = new ProgressBar(this);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(34), dp(34));
        bp.topMargin = dp(22);
        bar.setLayoutParams(bp);
        splashText = new TextView(this);
        splashText.setText("正在启动本地解析引擎…");
        splashText.setTextSize(13.5f);
        splashText.setTextColor(0xFF6B7280);
        splashText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(14);
        splashText.setLayoutParams(tp);
        splash.addView(title);
        splash.addView(bar);
        splash.addView(splashText);
        root.addView(splash, matchParent());

        setContentView(root);

        new Thread(this::startPython, "python-boot").start();
    }

    private FrameLayout.LayoutParams matchParent() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int unlockedBg() {
        return isSystemDark() ? Color.parseColor("#FF0E1015") : Color.parseColor("#FFF4F5F7");
    }

    private boolean isSystemDark() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private void applyBars(boolean dark) {
        try {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            View decor = getWindow().getDecorView();
            int vis = decor.getSystemUiVisibility()
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (dark) {
                vis &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                vis &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            } else {
                vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                vis |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            decor.setSystemUiVisibility(vis);
            if (webView != null) webView.setBackgroundColor(dark ? Color.parseColor("#FF0E1015") : Color.parseColor("#FFF1F3F7"));
        } catch (Throwable ignored) {
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- Python 服务
    private void startPython() {
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(getApplication()));
            }
            String webDir = new File(getFilesDir(), "web").getAbsolutePath();
            extractAssets("web", webDir);
            int port = Python.getInstance()
                    .getModule("novel_server")
                    .callAttr("start", PORT, getFilesDir().getAbsolutePath(), webDir)
                    .toJava(int.class);
            serverPort = port;
            serverReady = true;
            runOnUiThread(() -> webView.loadUrl("http://127.0.0.1:" + serverPort + "/?v=" + BuildConfig.VERSION_CODE));
        } catch (Throwable e) {
            e.printStackTrace();
            runOnUiThread(() -> {
                if (splashText != null) splashText.setText("本地引擎启动失败：" + e.getMessage());
            });
        }
    }

    private void hideSplash() {
        runOnUiThread(() -> {
            if (splash != null && splash.getParent() != null) {
                root.removeView(splash);
                splash = null;
            }
        });
    }

    private android.webkit.ValueCallback<Uri[]> pickCallback;

    /** 把 APK 内的 assets/web 解压到私有目录，供本地 HTTP 服务读取。
     *  必须按 versionCode 判断是否重解，否则覆盖安装后 WebView 会一直显示旧网页。 */
    private void extractAssets(String assetDir, String outDir) {
        File out = new File(outDir);
        File mark = new File(out, ".web_version");
        String want = String.valueOf(BuildConfig.VERSION_CODE);
        String have = "";
        try {
            if (mark.exists()) have = new String(java.nio.file.Files.readAllBytes(mark.toPath())).trim();
        } catch (Throwable ignored) {
        }
        if (out.exists() && new File(out, "index.html").exists() && want.equals(have)) {
            return;
        }
        deleteTree(out);
        out.mkdirs();
        try {
            copyAssetTree(getAssets(), assetDir, out);
            try (FileOutputStream os = new FileOutputStream(mark)) {
                os.write(want.getBytes("UTF-8"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void copyAssetTree(AssetManager am, String assetPath, File dest) throws Exception {
        String[] list = am.list(assetPath);
        if (list == null) return;
        for (String name : list) {
            String childAsset = assetPath + "/" + name;
            File child = new File(dest, name);
            String[] sub = am.list(childAsset);
            if (sub != null && sub.length > 0) {
                child.mkdirs();
                copyAssetTree(am, childAsset, child);
                continue;
            }
            try (InputStream in = am.open(childAsset);
                 FileOutputStream os = new FileOutputStream(child)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
        }
    }

    private void deleteTree(File f) {
        if (!f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteTree(k);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    // ---------------------------------------------------------------- 文件选择
    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == REQ_FILE) {
            Uri uri = (result == RESULT_OK && data != null) ? data.getData() : null;
            if (pickCallback != null) {
                pickCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
                pickCallback = null;
                return;
            }
            if (uri == null) {
                js("window.App && App.onPickCancel && App.onPickCancel()");
                return;
            }
            try {
                String name = displayName(uri);
                File dst = new File(getCacheDir(), "in_" + System.currentTimeMillis() + "_" + sanitize(name));
                copyToFile(uri, dst);
                JSONObject o = new JSONObject();
                o.put("path", dst.getAbsolutePath());
                o.put("name", name);
                o.put("size", dst.length());
                js("window.App && App.onFilePicked && App.onFilePicked(" + o.toString() + ")");
            } catch (Exception e) {
                js("window.App && App.onPickError && App.onPickError(" + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
            }
            return;
        }
        if (req == REQ_SAVE) {
            if (result != RESULT_OK || data == null || data.getData() == null || saveSource == null) {
                js("window.App && App.onSaved && App.onSaved(false, '')");
                cleanupSave();
                return;
            }
            try {
                Uri target = data.getData();
                try (InputStream in = new java.io.FileInputStream(saveSource);
                     OutputStream out = getContentResolver().openOutputStream(target, "w")) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                js("window.App && App.onSaved && App.onSaved(true, " + JSONObject.quote(saveName) + ")");
            } catch (Exception e) {
                js("window.App && App.onSaved && App.onSaved(false, " + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
            }
            cleanupSave();
        }
    }

    private void cleanupSave() {
        saveUri = null;
        saveName = null;
        saveSource = null;
    }

    private String displayName(Uri uri) {
        String name = null;
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (name == null) {
            name = uri.getLastPathSegment();
        }
        return name != null ? name : "book";
    }

    private static String sanitize(String name) {
        return name.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
    }

    private void copyToFile(Uri uri, File dst) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(dst)) {
            if (in == null) throw new Exception("无法读取文件");
            byte[] buf = new byte[8192];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 300L * 1024 * 1024) throw new Exception("文件超过 300MB");
                out.write(buf, 0, n);
            }
        }
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
        }
    }

    private void js(String code) {
        runOnUiThread(() -> webView.evaluateJavascript(code, null));
    }

    // ---------------------------------------------------------------- 供网页调用
    public class Bridge {

        @JavascriptInterface
        public String appVersion() {
            return BuildConfig.VERSION_NAME;
        }

        @JavascriptInterface
        public int appVersionCode() {
            return BuildConfig.VERSION_CODE;
        }

        @JavascriptInterface
        public String systemTheme() {
            return isSystemDark() ? "dark" : "light";
        }

        @JavascriptInterface
        public void saveThemeMode(String mode) {
            try { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("ui_theme", mode).apply(); }
            catch (Throwable ignored) { }
        }

        @JavascriptInterface
        public void setBars(String theme) {
            applyBars("dark".equals(theme));
        }

        @JavascriptInterface
        public String deviceInfo() {
            JSONObject o = new JSONObject();
            try {
                o.put("brand", Build.BRAND);
                o.put("model", Build.MODEL);
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("abi", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
            } catch (Exception ignored) {
            }
            return o.toString();
        }

        @JavascriptInterface
        public void toast(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public String clipboardText() {
            try {
                android.content.ClipboardManager cm = (android.content.ClipboardManager)
                        getSystemService(CLIPBOARD_SERVICE);
                if (cm == null || cm.getPrimaryClip() == null) return "";
                CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this);
                return t == null ? "" : t.toString().trim();
            } catch (Throwable e) {
                return "";
            }
        }

        /** 分享文本 / 书籍链接 */
        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(send, "分享链接"));
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "分享失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        /** 用用户指定的阅读器打开导出的书籍 */
        @JavascriptInterface
        public void openFile(String path, String name, String mime) {
            runOnUiThread(() -> {
                try {
                    File src = new File(path);
                    if (!src.exists()) {
                        Toast.makeText(MainActivity.this, "文件不存在，请先导出", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    File shared = new File(getCacheDir(), sanitize(name));
                    try (InputStream in = new java.io.FileInputStream(src);
                         FileOutputStream out = new FileOutputStream(shared)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    Uri u = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".files", shared);
                    Intent view = new Intent(Intent.ACTION_VIEW);
                    view.setDataAndType(u, mime == null || mime.isEmpty() ? "*/*" : mime);
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(view, "选择打开方式"));
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "打开失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        /** 把导出的文件分享到微信 / QQ / 邮件等 */
        @JavascriptInterface
        public void shareFile(String path, String name, String mime) {
            runOnUiThread(() -> {
                try {
                    File src = new File(path);
                    if (!src.exists()) {
                        Toast.makeText(MainActivity.this, "文件不存在", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    File shared = new File(getCacheDir(), sanitize(name));
                    try (InputStream in = new java.io.FileInputStream(src);
                         FileOutputStream out = new FileOutputStream(shared)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    Uri u = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".files", shared);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime == null || mime.isEmpty() ? "*/*" : mime);
                    send.putExtra(Intent.EXTRA_STREAM, u);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "分享 " + name));
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "分享失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            runOnUiThread(() -> openExternal(Uri.parse(url)));
        }

        /** 打开系统文件选择器，选完回调 App.onFilePicked({path,name,size}) */
        @JavascriptInterface
        public void pickFile() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/plain", "text/html", "application/epub+zip",
                        "application/zip", "application/octet-stream"
                });
                try {
                    startActivityForResult(i, REQ_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
                }
            });
        }

        /** 生成好的文件交给系统「另存为」，回调 App.onSaved(ok, name) */
        @JavascriptInterface
        public void saveFile(String path, String name, String mime) {
            runOnUiThread(() -> {
                File src = new File(path);
                if (!src.exists()) {
                    js("window.App && App.onSaved && App.onSaved(false, '文件不存在')");
                    return;
                }
                saveSource = src;
                saveName = name;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    js("window.App && App.onSaved && App.onSaved(false, " + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                }
            });
        }


        /** 检查更新：返回 update.json 内容 */
        @JavascriptInterface
        public void quit() {
            runOnUiThread(() -> finish());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
